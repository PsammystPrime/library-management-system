# library-management-system


this is a library management system in php
